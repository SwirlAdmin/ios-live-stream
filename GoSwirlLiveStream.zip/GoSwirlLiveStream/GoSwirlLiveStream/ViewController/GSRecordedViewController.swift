//
//  GSRecordedViewController.swift
//  GoSwirlLiveStream
//
//  Created by Pinkesh Gajjar on 04/09/23.
//

import UIKit

class GSRecordedViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
